Reinstalls the service with debug flags on or off 

CHANGE THE PATH TO THE SERIVCE FIRST IN BOTH BATCH FILES 
defaults to 

C:\squid

you might not have it installed there.
