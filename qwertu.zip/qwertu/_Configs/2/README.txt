NOTE:
ive Commented out ".microsoft.com" domain in the telemtery list
BECAUSE its enabled in the Windows updates list
And, you might (doubtful) want to re-enable updates at some point in the future, which will need the .microsoft.com domain
so if it was kept in the telemetry block list as well, then you'd fail to get updates when you renable it just the update enpoints. 


Blocks all windows telemetry Endpoints, and subdomains 

config file should be placed here:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
**YOUR SQUID INSTALL FOLDER**\etc\squid
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

