Blocks all windows update Endpoints, and subdomains 
Block all windows telemetry Endpoints, and subdomains.

config file should be placed here:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
**YOUR SQUID INSTALL FOLDER**\etc\squid
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

