This is basically just the same as a default Squid config
however it listens on all the private subnets by default 
its easier to just aadd singular ACLs to it later if you want 
