param (
    [string]$overridePath = "C:\Override\Path\script.bat"  # Default value
)

# Check if the overridePath parameter is empty
if (-not $overridePath) {
    Write-Host "Error: The override path cannot be empty."
    Read-Host "Press Enter to exit..."
    exit
}

# Define the path for the script and the task
$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$xmlFilePath = Join-Path -Path $scriptDirectory -ChildPath "SchedTask.xml"
$taskName = "Squid on Startup"

# Define the XML content with the new path
$xmlContent = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Date>$(Get-Date -Format "o")</Date>
    <Author>$(whoami)</Author>
    <Description>Ensures WinHTTP and WinINET Proxys are both on and pointing to Squid 127.0.0.1:3128 - and also ensure Squid is running, and service is up.</Description>
    <URI>\SchedTask</URI>
  </RegistrationInfo>
  <Triggers>
    <LogonTrigger>
      <Enabled>true</Enabled>
      <UserId>$(whoami)</UserId>
    </LogonTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <GroupId>S-1-5-32-544</GroupId>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>true</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>true</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>false</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings>
      <StopOnIdleEnd>true</StopOnIdleEnd>
      <RestartOnIdle>false</RestartOnIdle>
    </IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>true</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <DisallowStartOnRemoteAppSession>false</DisallowStartOnRemoteAppSession>
    <UseUnifiedSchedulingEngine>true</UseUnifiedSchedulingEngine>
    <WakeToRun>false</WakeToRun>
    <ExecutionTimeLimit>PT72H</ExecutionTimeLimit>
    <Priority>7</Priority>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>$overridePath</Command>
    </Exec>
  </Actions>
</Task>
"@

# Write the new XML content to the file, overwriting if it exists
$xmlContent | Out-File -FilePath $xmlFilePath -Encoding Unicode
Write-Host "New XML file created at: $xmlFilePath"

# Function to import the scheduled task
function Import-ScheduledTask {
    param (
        [string]$taskName,
        [string]$fileName,
        [string]$overridePath
    )

    # Remove existing task if it exists
    if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
        Write-Host "Removed existing task: $taskName"
    }

    # Import the new scheduled task
    $task = [xml](Get-Content $fileName)
    
    # Update the command path in the XML
    $commandNode = $task.SelectSingleNode("//Exec/Command")
    if ($commandNode -ne $null) {
        $commandNode.InnerText = $overridePath
        Write-Host "Updated task command path to: $overridePath"
    } else {
        Write-Host "No command path found in the XML to update."
    }

    # Register the scheduled task
    Register-ScheduledTask -Xml $task.OuterXml -TaskName $taskName
    Write-Host "Imported task: $taskName"
}

# Import the scheduled task
Import-ScheduledTask -taskName $taskName -fileName $xmlFilePath -overridePath $overridePath

# Delete the XML file after import
Remove-Item -Path $xmlFilePath -Force
Write-Host "Deleted the XML file: $xmlFilePath"

Write-Host "Scheduled task has been processed successfully."
